#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char* perpend(char* p1,char* p2,int n)
{
    int c,len1,len2;
    char *s;

    len1=strlen(p1);
    len2=strlen(p2);

    c=len1+len2-n;

    s=(char*)malloc((c+1)*sizeof(char));

    for(int i=0;i<c;i++)
    {
        if(i<len1-n)
        {
            *(s+i)=*(p1+n+i);
        }
        else
        {
            *(s+i)=*(p2+i-(len1-n));
        }
    }
    *(s+c)='\0';

    return s;
}

int main()
{
    char *p1,*p2,*p3;
    char s1[101],s2[101];
    int n;

    gets(s1);
    gets(s2);
    scanf("%d",&n);

    p1=s1;
    p2=s2;

    p3=perpend(s1,s2,n);

    for(int i=0;i<strlen(p3);i++)
    {
        printf("%c",*(p3+i));
    }

}
