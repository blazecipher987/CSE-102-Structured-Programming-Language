#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct comp{
    double x;
    double y;
};

void print(struct comp c)
{
    if(c.y>0)
    printf("%.2lf+%.2lfi\n",c.x,c.y);
    else if(c.y==0)
    printf("%.2lf\n",c.x);
    else if(c.y<0)
    printf("%.2lf-%.2lfi\n",c.x,-c.y);

}

struct comp multiply(struct comp n1,struct comp n2)
{
    struct comp c;

    c.x=n1.x*n2.x-n1.y*n2.y;

    c.y=n1.x*n2.y+n1.y*n2.x;

    return c;
}

struct comp division(struct comp n1,struct comp n2)
{
    struct comp c,Yc;

    Yc.x=n2.x;
    Yc.y=-n2.y;

    c=multiply(n1,Yc);

    int d=(n2.x*n2.x)+(n2.y*n2.y);

    c.x=c.x/d;
    c.y=c.y/d;

    return c;
}

int main()
{
    struct comp n1,n2,mul,div;
    scanf("%lf%lf%lf%lf",&n1.x,&n1.y,&n2.x,&n2.y);

    mul=multiply(n1,n2);
    div=division(n1,n2);

    print(mul);
    print(div);

}
