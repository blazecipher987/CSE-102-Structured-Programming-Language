#include<stdio.h>

int main()

{
    int p,q,i,j,n;

    scanf("%d",&n);

    for(i=1;i<2*n-1;i++)
    {
        for(j=1;j<=2*n-1;j++)
        {
            p=n-i;

            if(p<0)
                p=p*(-1);

            if(j>2*n-1-p)
                break;

            if(j<=p)
                printf(" ");
            else if (j==(2*n-1)-p || j==1+p)
                printf("*");
            else
                printf("-");




        }
        printf("\n");
    }






    return 0;
}
