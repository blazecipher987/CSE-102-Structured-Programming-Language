#include<stdio.h>
#include<string.h>

int sub_count(char p[35], char q[35], int x, int y)
{
    int;

    if(y==0 || (x==0 && y==0))
    {
        return 1;
    }

    if(x==0)
    {
        return 0;
    }

    if(p[(x-1)]== q[(y-1)])
    {
        return sub_count(p,q,x-1,y)+ sub_count(p,q,x-1,y-1);
    }

    else
        return sub_count(p,q,x-1,y);
}



int main()
{
    char a[35],b[35],lenA,lenB,i;

    gets(a);
    gets(b);

    lenA=strlen(a);
    lenB=strlen(b);

    i= sub_count(a,b,lenA,lenB);
    printf("%d",i);


    return 0;
}
